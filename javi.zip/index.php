<?php 
session_start(); 

?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>TruckQuest</title>
	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <link href="css/ie8fix.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Lato:400' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Lato:700' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Lato:900' rel='stylesheet' type='text/css'>
    <![endif]-->
	<?php include 'includes/links.php';?>
		<!-- Fav and touch icons -->
		<link rel="apple-touch-icon" sizes="180x180" href="img/favicon_io/apple-touch-icon.png">
		<link rel="icon" type="image/png" sizes="32x32" href="img/favicon_io/favicon-32x32.png">
		<link rel="icon" type="image/png" sizes="16x16" href="img/favicon_io/favicon-16x16.png">
		<link rel="manifest" href="img/favicon_io/site.webmanifest">	
</head>

<body id="top" data-spy="scroll" data-target=".navbar" data-offset="260">
	<!-- Header start -->
	<?php include 'includes/header.php';?>
		<!-- Header end -->
		<!-- Teaser start -->
		<section id="teaser">
			<div class="container">
				<div class="row">
					<div class="col-md-7 col-xs-12 pull-right">
						<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
							<!-- Wrapper for slides start -->
							<div class="carousel-inner">

								<div class="item active">
									<h1 class="title">Get real time pricing
                      <span class="subtitle">Plan now</span></h1>
									<div class="car-img"> <img src="img/truck.png" class="img-responsive" alt="TruckQuest Truck image"> </div>
								</div>
							</div>
							<!-- Wrapper for slides end -->
             </div>
					</div>
					<div class="col-md-5 col-xs-12 pull-left">
						<div class="reservation-form-shadow">
							<form action="#" method="post" name="car-select-form" id="book_now_form">
								<div class="alert alert-danger hidden" id="car-select-form-msg">
									<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button> <strong>Note:</strong> All fields required! </div>
								<!-- Car select start -->
								<div class="styled-select-car">
									<select name="v_type" id="car-select" required>
										<option value="">Select Vehicle Type <span style="color:red">*</span></option>
										 <?php
										$stmt = $dbConn->prepare("SELECT * FROM `vehicle_group`");
										$stmt->execute();
										$count = $stmt->rowCount();
										if ($count > 0) {
											$fetch_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
											for ($i = 0; $i < $count; $i++) {
												?>
													<option value="<?=$fetch_data[$i]["gr_id"]?>"><?=$fetch_data[$i]["gr_name"]?></option>
													<?php
												}
										}

										?>
									</select>
								</div>
								<!-- Car select end -->
								<!-- Pick-up location start -->
								<div class="location">
									<div class="input-group pick-up"> <span class="input-group-addon"><span class="glyphicon glyphicon-map-marker"></span> Pick-up <span style="color:red">*</span></span>
										<input type="text" name="pick-up-location" id="pick-up-location" class="form-control autocomplete-location" placeholder="Enter a City or Town" required> </div>
								</div>
								<!-- Drop-off location end -->
								<div class="location">
								 	<div class="input-group pick-up"> <span class="input-group-addon"><span class="glyphicon glyphicon-map-marker"></span> Drop <span style="color:red">*</span> </span>
									<input type="text" name="drop-location" id="drop-up-location" class="form-control autocomplete-location" placeholder="Enter a City or Town" onchange="calculate_distance()" required> </div>

								</div>
								<!-- Pick-up date/time start -->
								<div class="datetime pick-up">
										<div class="input-group"> <span class="input-group-addon pixelfix"><span class="glyphicon glyphicon-calendar"></span> Pick-up <span style="color:red">*</span></span>
											<input type="text" readonly="true" name="pick-up-date" id="pick-up-date" class="form-control datepicker" placeholder="MM/DD/YYYY"required> </div>


									<div class="clearfix"></div>
								</div>
								<!-- Pick-up date/time end -->

								<input type="hidden" class="submit" name="save_request" value="Book Now" id="checkoutModalLabel">  
								<input type="submit" class="submit" name="save_request" value="Book Now" id="checkoutModalLabel"> </form>
						</div>
					</div>
				</div>
			</div>
		</section>
		<div class="arrow-down"></div>
		<!-- Teaser end -->
		<!-- Services start -->
		<section id="services" class="container">
			<div class="row">
				<div class="col-md-12 title">
					<h2>Services</h2> <span class="underline">&nbsp;</span> </div>
				<!-- Service Box start -->
				<div class="col-md-4">
					<div class="service-box wow fadeInLeft" data-wow-offset="100">
						<div class="service-icon"><img src="img/icons/leadership.png" style="width:100%"></div>
						<h3 class="service-title">Leadership</h3>
						<div class="clearfix"></div>
						<p class="service-content">Experts who have extensive, hands-on experience in supply chain management.</p>
					</div>
				</div>
				<!-- Service Box end --> 
				<!-- Service Box start -->
				<div class="col-md-4">
					<div class="service-box wow fadeInLeft" data-wow-offset="100">
						<div class="service-icon"><img src="img/icons/technology.png" style="width:100%"></div>
						<h3 class="service-title">Technology</h3>
						<div class="clearfix"></div>
						<p class="service-content">Innovative and varied use of technology on the road, ocean, railways, in the air.</p>
					</div>
				</div>
				<!-- Service Box end --> 
				<!-- Service Box start -->
				<div class="col-md-4">
					<div class="service-box wow fadeInLeft" data-wow-offset="100">
						<div class="service-icon"><img src="img/icons/solution.png" style="width:100%"></div>
						<h3 class="service-title">Solution</h3>
						<div class="clearfix"></div>
						<p class="service-content">Global leaders in intermodal, less-than-truckload, supply chain management.</p>
					</div>
				</div>
				<!-- Service Box end --> 
			</div>
		</section>
		<!-- Services end -->
		<!-- Newsletter start -->
		<section id="newsletter" class="wow slideInLeft" data-wow-offset="300">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						 <h2 class="count">"We help part of the Supply Chain, logistics industry, and multiple land carriers to improve, integrate and streamline their operations and mutual communication, No more empty miles, reducing carbon emissions to contribute to the Environment."</h2>	
					</div> 
				</div>
			</div>
		</section>
		<!-- Newsletter end -->
		<!-- Newsletter start -->
		<section id="newsletter" class="wow slideInLeft" data-wow-offset="300">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						 
					</div>
					<div class="col-md-3 col-xs-12 text-center">
						 <img src="img/icons/appdownload.png" style="width:60%">
						 <span><h2 class="count"><b>8 M+</b></h2></span><br>
						 <span><h3 class="count">App downloads<h3></span><br> 
					</div> 
					<div class="col-md-3 col-xs-12 text-center">
						 <img src="img/icons/business.png" style="width:60%">
						 <span><h2 class="count"><b>700 M+</b></h2></span><br>
						 <span><h3 class="count">Truck-safe miles routed<h3></span><br> 
					</div>
					<div class="col-md-3 col-xs-12 text-center">
						 <img src="img/icons/community.png" style="width:60%">
						 <span><h2 class="count"><b>4 M+</b></h2></span><br>
						 <span><h3 class="count">Community generated updates<h3></span><br> 
					</div>
					<div class="col-md-3 col-xs-12 text-center">
						 <img src="img/icons/truck.png" style="width:60%">
						 <span><h2 class="count"><b>500 K+</b></h2></span><br>
						 <span><h3 class="count">Local business partners<h3></span><br> 
					</div>
				</div>
			</div>
		</section>
		<!-- Newsletter end --> 
		<!-- Partners start -->
		<section id="partners" class="wow fadeIn" data-wow-offset="50">
			<div class="container">
				<div class="row">
					<div class="col-md-12 text-center">
						<h2>Track Your Shipment Here</h2> <span class="underline">&nbsp;</span>
						<!-- <p>To contribute to positive change and achieve our sustainability goals, we partner with many extraordinary organizations around the world. Their expertise enables us to do far more than we could alone, and their passion and talent inspire us. It is our pleasure to introduce you to a handful of the organizations whose accomplishments and commitments are representative of all the organizations we are fortunate to call our partners.</p> -->
					</div>
					<div class="col-md-12 col-xs-12 text-center"> 
						<form>
							<div class="form-group col-md-12"> 
								<input type="text" class="input" id="email" placeholder="Enter Shipment ID">
							</div>
							<div class="form-group col-md-12 text-center">  
									<input type="submit" class="btn submit" name="submit" value="Track" id="checkoutModalLabel">
							</div> 
							 
							
						</form>
					</div> 
				</div>
			</div>
		</section>
		<!-- Partners end -->
		<!-- Contact start -->
		<section id="contact" class="container wow bounceInUp" data-wow-offset="50">
			<div class="row">
				<div class="col-md-12">
					<h2>Contact Us</h2> </div>
				 
				<div class="col-md-12 col-xs-12 pull-left">
					<p class="contact-info">You have any questions or need additional information?
					 </p>
					<form action="#" method="post" id="contact-form" name="contact-form"> 
						<div class="form-group">
							<input type="email" class="form-control email text-field" name="email" placeholder="Enter Email"> </div>
						<div class="form-group">
							<textarea class="form-control message" name="message" placeholder="Message:"></textarea>
						</div>
						<input type="hidden"  name="submit-message" value="Submit">  
						<input type="submit" class="btn submit-message" value="Submit Query"> </form>
				</div>
			</div>
		</section>
		<!-- Contact end --><a href="#" class="scrollup">ScrollUp</a>
		<!-- Footer start -->
		<?php include 'includes/footer.php';?>
			<!-- Footer end -->
			<!-- Checkout Modal Start -->
			<div class="modal fade" id="checkoutModal" tabindex="-1" role="dialog" aria-labelledby="checkoutModalLabel" aria-hidden="true" data-backdrop="static">
				<div class="modal-dialog">
					<div class="modal-content">
						<form action="#" method="post" id="checkout-form" name="checkout-form">
							<input type="hidden" name="action" value="send_inquiry_form" />
							<input type="text" class="website_hp" name="website_hp" />
							<!-- Modal header start -->
							<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
								<h4 class="modal-title" id="myModalLabel">Complete reservation</h4> </div>
							<!-- Modal header end -->
							<!-- Modal body start -->
							<div class="modal-body">
								<!-- Checkout Info start -->
								<div class="checkout-info-box">
									<h3><i class="fa fa-info-circle"></i> Upon completing this reservation enquiry, you will receive::</h3>
									<p>Your rental voucher to produce on arrival at the rental desk and a toll-free customer support number.</p>
								</div>
								<!-- Checkout Info end -->
								<!-- Checkout Rental Info start -->
								<div class="checkout-vehicle-info">
									<div class="location-date-info">
										<h3>Location & Date</h3>
										<div class="info-box"> <span class="glyphicon glyphicon-calendar"></span>
											<h4 class="info-box-title">Pick-Up Time</h4>
											<p class="info-box-description"><span id="pick-up-date-ph"></span> at <span id="pick-up-time-ph"></span></p>
											<input type="hidden" name="pick-up" id="pick-up" value=""> </div>
										<div class="info-box"> <span class="glyphicon glyphicon-calendar"></span>
											<h4 class="info-box-title">Drop-Off Time</h4>
											<p class="info-box-description"><span id="drop-off-date-ph"></span> at <span id="drop-off-time-ph"></span></p>
											<input type="hidden" name="drop-off" id="drop-off" value=""> </div>
										<div class="info-box"> <span class="glyphicon glyphicon-map-marker"></span>
											<h4 class="info-box-title">Pick-Up Location</h4>
											<p class="info-box-description" id="pickup-location-ph"></p>
											<input type="hidden" name="pickup-location" id="pickup-location" value=""> </div>
										<div class="info-box"> <span class="glyphicon glyphicon-map-marker"></span>
											<h4 class="info-box-title">Drop-Off Location</h4>
											<p class="info-box-description" id="dropoff-location-ph"></p>
											<input type="hidden" name="dropoff-location" id="dropoff-location" value=""> </div>
									</div>
									<div class="vehicle-info">
										<h3>CAR: <span id="selected-car-ph"></span></h3> <a href="#vehicles" class="scroll-to">[ Vehicle Models ]</a>
										<input type="hidden" name="selected-car" id="selected-car" value="">
										<div class="clearfix"></div>
										<div class="vehicle-image"> <img class="img-responsive" id="selected-vehicle-image" src="img/vehicle1.jpg" alt="Vehicle"> </div>
									</div>
									<div class="clearfix"></div>
								</div>
								<!-- Checkout Rental Info end -->
								<hr>
								<!-- Checkout Personal Info start -->
								<div class="checkout-personal-info">
									<div class="alert hidden" id="checkout-form-msg"> test </div>
									<h3>PERSONAL INFORMATION</h3>
									<div class="form-group left">
										<label for="first-name">First Name:</label>
										<input type="text" class="form-control" name="first-name" id="first-name" placeholder="Enter your first name"> </div>
									<div class="form-group right">
										<label for="last-name">Last Name:</label>
										<input type="text" class="form-control" name="last-name" id="last-name" placeholder="Enter your last name"> </div>
									<div class="form-group left">
										<label for="phone-number">Phone Number:</label>
										<input type="text" class="form-control" name="phone-number" id="phone-number" placeholder="Enter your phone number"> </div>
									<div class="form-group right age">
										<label for="age">Age:</label>
										<div class="styled-select-age">
											<select name="age" id="age">
												<option value="18">18</option>
												<option value="19">19</option>
												<option value="20">20</option>
												<option value="21">21</option>
												<option value="22">22</option>
												<option value="23">23</option>
												<option value="24">24</option>
												<option value="25">25</option>
												<option value="26">26</option>
												<option value="27">27</option>
												<option value="28">28</option>
												<option value="29">29</option>
												<option value="30">30</option>
												<option value="31">31</option>
												<option value="32">32</option>
												<option value="33">33</option>
												<option value="34">34</option>
												<option value="35">35</option>
												<option value="36">36</option>
												<option value="37">37</option>
												<option value="38">38</option>
												<option value="39">39</option>
												<option value="40">40</option>
												<option value="41">41</option>
												<option value="42">42</option>
												<option value="43">43</option>
												<option value="44">44</option>
												<option value="45">45</option>
												<option value="46">46</option>
												<option value="47">47</option>
												<option value="48">48</option>
												<option value="49">49</option>
												<option value="50">50</option>
												<option value="51">51</option>
												<option value="52">52</option>
												<option value="53">53</option>
												<option value="54">54</option>
												<option value="55">55</option>
												<option value="56">56</option>
												<option value="57">57</option>
												<option value="58">58</option>
												<option value="59">59</option>
												<option value="50">50</option>
												<option value="61">61</option>
												<option value="62">62</option>
												<option value="63">63</option>
												<option value="64">64</option>
												<option value="65">65</option>
												<option value="66">66</option>
												<option value="67">67</option>
												<option value="68">68</option>
												<option value="69">69</option>
												<option value="70">70</option>
												<option value="71">71</option>
												<option value="72">72</option>
												<option value="73">73</option>
												<option value="74">74</option>
												<option value="75">75</option>
												<option value="76">76</option>
												<option value="77">77</option>
												<option value="78">78</option>
												<option value="79">79</option>
												<option value="80">80</option>
												<option value="81">81</option>
												<option value="82">82</option>
												<option value="83">83</option>
												<option value="84">84</option>
												<option value="85">85</option>
												<option value="86">86</option>
												<option value="87">87</option>
												<option value="88">88</option>
												<option value="89">89</option>
												<option value="90">90</option>
												<option value="91">91</option>
												<option value="92">92</option>
												<option value="93">93</option>
												<option value="94">94</option>
												<option value="95">95</option>
												<option value="96">96</option>
												<option value="97">97</option>
												<option value="98">98</option>
												<option value="99">99</option>
												<option value="100">100</option>
											</select>
										</div>
									</div>
									<div class="form-group left">
										<label for="email-address">Email Address:</label>
										<input type="email" class="form-control" name="email-address" id="email-address" placeholder="Enter your email address"> </div>
									<div class="form-group right">
										<label for="email-address-confirm">Confirm Email Address:</label>
										<input type="email" class="form-control" name="email-address-confirm" id="email-address-confirm" placeholder="Confirm your email address"> </div>
									<div class="clearfix"></div>
								</div>
								<!-- Checkout Personal Info end -->
								<!-- Checkout Address Info start -->
								<div class="checkout-address-info">
									<div class="form-group address">
										<label for="address">Address</label>
										<input type="text" class="form-control" name="address" id="address" placeholder="Enter your Street an No."> </div>
									<div class="form-group city">
										<label for="city">City</label>
										<input type="text" class="form-control" name="city" id="city" placeholder="Enter your City"> </div>
									<div class="form-group zip-code">
										<label for="zip-code">Zip Code</label>
										<input type="text" class="form-control" name="zip-code" id="zip-code" placeholder="Enter your Zip Code"> </div>
									<div class="clearfix"></div>
								</div>
								<!-- Checkout Address Info end -->
								<div class="newsletter">
									<div class="form-group">
										<div class="checkbox">
											<input id="check1" type="checkbox" name="newsletter" value="yes">
											<label for="check1">Please send me latest news and updates</label>
										</div>
									</div>
								</div>
							</div>
							<!-- Modal body end -->
							<!-- Modal footer start -->
							<div class="modal-footer"> <span class="btn-border btn-gray">
                    <button type="button" class="btn btn-default btn-gray" data-dismiss="modal">Cancel</button>
                  </span> <span class="btn-border btn-yellow">
                    <button type="submit" class="btn btn-primary btn-yellow">Reserve now</button>
                  </span> </div>
							<!-- Modal footer end -->
						</form>
					</div>
				</div>
			</div>
			<!-- Checkout Modal end -->
			<?php include 'includes/scripts.php';?>
</body>

</html>