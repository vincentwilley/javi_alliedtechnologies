<footer>
    <div class="container">
        <div class="row">
        <div class="col-md-12 text-center">
            <ul class="footer-nav">
            <li><a class="scroll-to" href="#top">Home</a></li>
            <li><a class="scroll-to" href="#services">Service</a></li>
            <li><a class="scroll-to" href="#vehicles">Vehicle Models</a></li>
            <li><a class="scroll-to" href="#reviews">Reviews</a></li>
            <li><a class="scroll-to" href="#locations">Locations</a></li>
            <li><a class="scroll-to" href="#contact">Contact</a></li>
            </ul>
            <div class="clearfix"></div>
            <p class="copyright">©2022 Allied Technologies, All Rights Reserved</p>
        </div>
        </div>
    </div>
</footer>