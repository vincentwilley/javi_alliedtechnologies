<!-- This page will have all the script tags written at bottom, before body closes -->
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery-1.11.0.min.js?key=<?=date('sis')?>"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->

<script src="js/bootstrap.min.js?key=<?=date('sis')?>"></script>
<script src="js/jquery.autocomplete.min.js?key=<?=date('sis')?>"></script>
<script src="js/jquery.placeholder.js?key=<?=date('sis')?>"></script>
<script src="js/locations-autocomplete.js?key=<?=date('sis')?>"></script>
<script src="js/bootstrap-datepicker.js?key=<?=date('sis')?>"></script> 
<!-- <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBsr1sFUtzPoVl9GIKmp1dXCS04tcJ9NfI" type="text/javascript"></script> -->
 
<!--[if !(gte IE 8)]><!-->
<script src="js/wow.min.js?key=<?=date('sis')?>"></script>
<script>
    // Initialize WOW
    //-------------------------------------------------------------
    new WOW({mobile: false}).init();
</script>
<!--<![endif]-->

<script src="js/custom.js?key=<?=date('sis')?>"></script>
