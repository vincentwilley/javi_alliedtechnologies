  <!-- This page will have all css links that are in head tag of html -->

  <!-- Bootstrap -->
  <link href="css/bootstrap.min.css" rel="stylesheet">

  <!-- Bootstrap -->
  <link href="css/animate.css" rel="stylesheet">

  <!-- Google Font Lato -->
  <link href='http://fonts.googleapis.com/css?family=Nunito:400,700,900,400italic,700italic,900italic' rel='stylesheet' type='text/css'>
  <link rel="stylesheet" href="css/font-awesome.min.css">

  <!-- Plugin Styles -->
  <link href="css/datepicker.css" rel="stylesheet">


  <!-- Main Styles -->
  <link href="css/styles.css?7" rel="stylesheet">
  <!-- Available main styles: styles-red.css, styles-green.css -->

  <style>
      form .website_hp{
          display: none;
      }
      .count{
       color:white;
      }
     .btn {
            width: 100%;
            background-color: #fe6e3e;
            color: #fff;
            border: none;
            border-radius: 0;
            box-shadow: 6px 6px 0 #efe9e9;
            text-align: center;
            font-size: 24px;
            text-transform: uppercase;
            font-weight: 900;
            padding: 10px 0;
            margin-top: 30px;
            transition: 0.2s;
        }
    .input {
            border-radius: 0;
            color: #fe6e3e;
            font-size: 16px;
            padding-left: 15px;
            box-shadow: none;
            background: none;
            -webkit-appearance: none;
            height: 60px;

            width: 100%;
            border: 2px solid #efe9e9;
        }
        #snackbar {
            visibility: hidden;
            min-width: 250px;
            margin-left: -125px;
            background-color: #333;
            color: #fff;
            text-align: center;
            border-radius: 2px;
            padding: 16px;
            position: fixed;
            z-index: 1;
            left: 50%;
            bottom: 30px;
            font-size: 17px;
        }

        #snackbar.show {
            visibility: visible;
            -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
            animation: fadein 0.5s, fadeout 0.5s 2.5s;
        }

        @-webkit-keyframes fadein {
            from {bottom: 0; opacity: 0;}
            to {bottom: 30px; opacity: 1;}
        }

        @keyframes fadein {
            from {bottom: 0; opacity: 0;}
            to {bottom: 30px; opacity: 1;}
        }

        @-webkit-keyframes fadeout {
            from {bottom: 30px; opacity: 1;}
            to {bottom: 0; opacity: 0;}
        }

        @keyframes fadeout {
            from {bottom: 30px; opacity: 1;}
            to {bottom: 0; opacity: 0;}
        }
  </style>
