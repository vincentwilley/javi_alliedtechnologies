function LoadMaps(){
var uluru = { lat: -25.344, lng: 131.036 };
  // The map, centered at Uluru
  var map = new google.maps.Map(
    document.getElementById("mapp"),
    {
      zoom: 4,
      center: uluru
    });

}

