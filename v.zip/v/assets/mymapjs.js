function LoadMap(){
var california = { lat: 37.229564, lng: -120.047533 };
  // The map, centered at california
  var map = new google.maps.Map(
    document.getElementById("map"),
    {
      zoom: 10,
      center: california
    });

}

